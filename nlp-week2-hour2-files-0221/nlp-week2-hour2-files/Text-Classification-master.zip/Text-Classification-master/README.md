# Text Classification 

This is an easy to understand script for 'Text Classfication' using SVM and Naive Bayes. 

The input file is also uploaded corpus.csv

Refer Below for detailed explanation
https://medium.com/@bedigunjit/simple-guide-to-text-classification-nlp-using-svm-and-naive-bayes-with-python-421db3a72d34
